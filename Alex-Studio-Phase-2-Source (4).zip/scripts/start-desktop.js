#!/usr/bin/env node
/**
 * Alex Studio Desktop Standalone Launcher
 * Launches Alex Studio as a standalone desktop window without browser chrome.
 * Cross-platform support for Windows, macOS, and Linux.
 */
const { spawn, exec } = require('child_process');
const http = require('http');

const PORT = process.env.PORT || 3000;
const URL_STRING = 'http://localhost:' + PORT;

function checkServerReady(timeout) {
  const maxTimeout = timeout || 30000;
  const start = Date.now();
  return new Promise((resolve, reject) => {
    const interval = setInterval(() => {
      http.get(URL_STRING, (res) => {
        clearInterval(interval);
        resolve(true);
      }).on('error', () => {
        if (Date.now() - start > maxTimeout) {
          clearInterval(interval);
          reject(new Error('Server boot timed out'));
        }
      });
    }, 500);
  });
}

function launchDesktopWindow() {
  const platform = process.platform;
  console.log('[Alex Studio] Launching standalone desktop window on ' + platform + '...');

  let cmd = '';
  if (platform === 'win32') {
    cmd = 'start msedge --app=' + URL_STRING + ' || start chrome --app=' + URL_STRING + ' || start ' + URL_STRING;
  } else if (platform === 'darwin') {
    cmd = 'open -na "Google Chrome" --args --app=' + URL_STRING + ' || open -na "Brave Browser" --args --app=' + URL_STRING + ' || open ' + URL_STRING;
  } else {
    cmd = 'google-chrome --app=' + URL_STRING + ' || chromium-browser --app=' + URL_STRING + ' || chromium --app=' + URL_STRING + ' || xdg-open ' + URL_STRING;
  }

  exec(cmd, (err) => {
    if (err) {
      console.warn('[Alex Studio] Direct window launch error, opening default URL:', err.message);
      const fallback = platform === 'win32' ? ('start ' + URL_STRING) : platform === 'darwin' ? ('open ' + URL_STRING) : ('xdg-open ' + URL_STRING);
      exec(fallback);
    } else {
      console.log('[Alex Studio] Standalone desktop window opened at ' + URL_STRING);
    }
  });
}

async function main() {
  console.log('====================================================');
  console.log('   Alex Studio — Desktop Launcher (Phase 2)');
  console.log('   Local-First • 100% Free • Standalone Workspace');
  console.log('====================================================');

  try {
    await checkServerReady(2000);
    console.log('[Alex Studio] Detected active server at ' + URL_STRING);
    launchDesktopWindow();
  } catch {
    console.log('[Alex Studio] Starting local server on port ' + PORT + '...');
    const server = spawn('npm', ['run', 'dev'], { stdio: 'inherit', shell: true });

    process.on('SIGINT', () => {
      console.log('\n[Alex Studio] Shutting down desktop session...');
      server.kill();
      process.exit(0);
    });

    try {
      await checkServerReady(30000);
      launchDesktopWindow();
    } catch (err) {
      console.error('[Alex Studio] Failed to start local server:', err.message);
    }
  }
}

main();
